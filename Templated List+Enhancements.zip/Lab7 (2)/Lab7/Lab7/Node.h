//Name: Luis Solis
//Programming Assignment: Templated List Enhancements
#pragma once
#include <iostream>

using std::cout;
using std::endl;

template<class data>
class LinkedList;
template<class t>
class Iterator;


template <class Type>
class Node
{
	friend class LinkedList<Type>;
	friend class Iterator<Type>;
private:
	Type nodeData;
	Node <Type>* nextPointer;
	Node();
	Node(const Node<Type>& other);
	~Node();
	Node(Node<Type>&& other);
	Node& operator = (const Node<Type>& other);
	Node& operator = (Node<Type>&& other);
	Node(Type data, Node<Type>* nextPointer = nullptr);

};
/*
	Implementation sections of the templated node class
*/
template <class Type>
Node<Type>::Node() : nextPointer(nullptr), nodeData()  //nextPointer=nullptr
{
	cout << "Node Default ctor" << endl;
}
template <class Type>
Node<Type>::Node(const Node<Type>& other) : nextPointer(nullptr), nodeData(other.nodeData)
{
	cout << "Node Copy Ctor" << endl;
}
template <class Type>
Node<Type>::~Node()
{
	cout << "Node Dtor" << endl;
}

template <class Type>
Node<Type>::Node(Node<Type>&& other) :nextPointer(nullptr), nodeData(std::move(other.nodeData))
{
	cout << "Node Move ctor" << endl;
}

template <class Type>
Node<Type>& Node<Type>::operator=(const Node<Type>& other)
{
	cout << "Node Copy Assignment" << endl;
	if (this != &other)
	{
		nodeData = other.nodeData;
	}
	return *this;
}
template <class Type>
Node<Type>& Node<Type>::operator=(Node<Type>&& other)
{
	cout << "Node Move Assignment" << endl;
	if (this != &other)
	{
		nodeData = std::move(other.nodeData);
	}
	return *this;
}

template <class Type>
Node<Type>::Node(Type value, Node<Type>* nextNode) : nodeData(value), nextPointer(nextNode)
{
	cout << "Node creation" << endl;
}
