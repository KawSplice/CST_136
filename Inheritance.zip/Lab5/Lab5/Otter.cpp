//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>
#include "Otter.h"

using std::cout;
using std::endl;

Otter::Otter() : Mammal("Otter"), m_sea(0),Animal("tiger")
{
	//cout << "Otter default ctor" << endl;
}

Otter::Otter(bool points) : Mammal("Otter"), m_sea(points),Animal("tiger")
{
	//cout << "Otter one arg ctor" << endl;
}

Otter::~Otter()
{
	//cout << "Otter dtor" << endl;
}

Otter& Otter::operator = (const Otter& rhs)
{
	//cout << "Otter copy =" << endl;
	if (this != &rhs)
	{
		Mammal::operator = (rhs);
		m_sea = rhs.m_sea;
	}
	return *this;
}

Otter::Otter(const Otter& other) : Mammal(other), m_sea(other.m_sea),Animal("tiger")
{
	//cout << "Otter copy ctor" << endl;
}

Otter& Otter::operator = (Otter&& rhs) noexcept
{
	cout << "Otter move =" << endl;
	if (this != &rhs)
	{
		Mammal::operator = (static_cast<Otter&&>(rhs));
		m_sea = rhs.m_sea;
	}
	return *this;
}

Otter::Otter(Otter&& other) noexcept : Mammal(static_cast<Otter&&>(other)), m_sea(other.m_sea), Animal("tiger")
{
	//cout << "Otter move ctor" << endl;
}

void Otter::WhatAmI()
{
	cout << "I am an Otter" << endl;
}
