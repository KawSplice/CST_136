//Name: Luis Solis
//Programming Assignment: Lab 4
#pragma once
#include <iostream>

using std::ostream;

class String {

private: char* c_string;                       //string that will hold out variable
public:
	String();						           //default
	String(const String& other);               //copy
	~String();						           //dtor
	String(String&& other);					   //move ctor
	String(const char* cstring);			   //1 arg
	const char* GetCString() const;			   //GetCString
	int GetSize() const;					   //GetSize

	String& operator = (const String& other);		//copy assignment
	String& operator = (String&& other);			//move assignement
	bool operator < (const String& other) const;	// < 
	bool operator > (const String& other) const;	// >
	bool operator <= (const String& other) const;	// <=
	bool operator >= (const String& other) const;	// >= 
	bool operator == (const String& other) const;	// == 
	bool operator != (const String& other) const;	// != 
	String operator + (const String& other) const;	// +
	String& operator += (const String&other);		// +=
	char operator[] (int num)const;					// []

};