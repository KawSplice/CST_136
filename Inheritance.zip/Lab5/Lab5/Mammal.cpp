//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>
#include "Mammal.h"

using std::cout;
using std::endl;

Mammal::Mammal() : Animal("Mammal")
{
	//cout << "Mammal default ctor" << endl;
}

Mammal::Mammal(string species) : Animal(species)
{
	//cout << "Mammal one arg ctor" << endl;
}

Mammal::~Mammal()
{
	//cout << "Mammal dtor" << endl;
}

Mammal& Mammal::operator = (const Mammal& rhs)
{
	//cout << "Mammal copy =" << endl;
	if (this != &rhs)
	{
		Animal::operator=(rhs);
	}
	return *this;
}

Mammal::Mammal(const Mammal& other) : Animal(other.GetSpecies())
{
	//cout << "Mammal copy ctor" << endl;
}

Mammal& Mammal::operator = (Mammal&& rhs) noexcept
{
	//cout << "Mammal move =" << endl;
	if (this != &rhs)
	{
		//m_species = static_cast<string&&> (rhs.m_species);
		Animal::operator = (static_cast<Animal&&>(rhs));
		//Animal::operator= rhs.GetSpecies();
	}
	return *this;
}

Mammal::Mammal(Mammal&& other) noexcept : Animal(other.GetSpecies())
{
	cout << "Mammal move ctor" << endl;
}

void Mammal::WhatAmI()
{
	cout << "I am a mammal" << endl;
}

////const string Mammal::GetSpecies() const
////{
////	return m_species;
////}