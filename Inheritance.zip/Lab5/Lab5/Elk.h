//Name: Luis Solis
//Programming Assignment: Inheritance
#ifndef _ELK_H
#define _ELK_H

#include "Mammal.h"

class Elk : public Mammal
{
public:
	Elk();
	Elk(int points);
	~Elk();
	Elk& operator = (const Elk& rhs);
	Elk(const Elk& copy);
	Elk& operator = (Elk&& rhs) noexcept;
	Elk(Elk&& copy) noexcept;
	void WhatAmI();
protected:
	int m_points;
};
#endif
