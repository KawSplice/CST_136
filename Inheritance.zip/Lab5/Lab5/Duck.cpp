//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>

#include "Duck.h"

using std::endl;
using std::cout;


Duck::Duck() :Bird("robin"),Animal("tiger")
{

}
Duck::Duck(string other) : Bird(other),Animal("tiger")
{

}
Duck::~Duck()
{

}
Duck& Duck::operator = (const Duck& rhs)
{
	if (this != &rhs)
	{
		Bird::operator=(rhs);
	}
	return *this;
}
Duck::Duck(const Duck& copy) :Bird(copy.GetSpecies()),Animal("tiger")
{

}
Duck& Duck::operator = (Duck&& rhs) noexcept
{
	if (this != &rhs)
	{
		Bird::operator = (static_cast<Bird&&>(rhs));
	}
	return *this;
}
Duck::Duck(Duck&& copy) noexcept : Bird(copy.GetSpecies()),Animal("tiger")
{

}
void Duck::WhatAmI()
{
	cout << "I am a Duck" << endl;
}

