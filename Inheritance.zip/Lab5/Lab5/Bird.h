//Name: Luis Solis
//Programming Assignment: Inheritance
#ifndef _Bird_H
#define _Bird_H

#include "Animal.h"

class Bird : virtual public Animal
{
public:
	Bird();
	Bird(string other);
	~Bird();
	Bird& operator = (const Bird& rhs);
	Bird(const Bird& copy);
	Bird& operator = (Bird&& rhs) noexcept;
	Bird(Bird&& copy) noexcept;
	void WhatAmI();
private:

};
#endif