//Name: Luis Solis
//Programming Assignment: Lab4
//defines and includes used
#define _CRTDBG_MAP_ALLOC
#include <iostream>
#include <crtdbg.h>
#include "String.h"

using std::endl;
using std::cout;
using std::ostream;

ostream& operator << (ostream& other, const String&);
int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	String name = "hey";
	String name2 = "hello";
	String c_name = "hey";
	c_name = "hello";
	String n_name = c_name;
	name < name2;
	name2 > name;
	name <= name2; 
	name2 >= name;
	name == name2;
	name != name2;
	name + name2;
	name += name2;
	cout << name2;
	
	name.GetSize();
	try
	{
		name[2];
		name2[7];
	}
	catch(...)
	{
		cout << "we caught a fish" << endl;
	}
	name = name2;
	return 0;
}
ostream& operator << (ostream& other, const String& string_n)
{
	cout << "Operator << " << endl;
	return other << string_n.GetCString() << endl;
}
