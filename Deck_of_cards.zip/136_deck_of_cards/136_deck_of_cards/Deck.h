//Name: Luis Solis  
//Programming Assignment:Deck of cards 
#pragma once
#include "Cards.h"
//deck class
class Deck {
private:
    Card m_deck[52];
    int m_current;

public:
    Deck();                                 //default
    Deck(const Deck& m_current);           //copy ctor
    ~Deck();                                //dtor
    Deck& operator = (const Deck& rhs);	//copy assignment
    Deck(Deck&& rhs);			    //move 
    Deck& operator = (Deck&& rhs);  //move assignment 
};