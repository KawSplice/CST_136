//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>
#include "Bird.h"

using std::cout;
using std::endl;

Bird::Bird() :Animal("tiger")
{

}
Bird::Bird(string other) : Animal(other)
{

}
Bird::~Bird()
{

}
Bird& Bird::operator = (const Bird& rhs)
{
	if (this != &rhs)
	{
		Animal::operator=(rhs);
	}
	return *this;
}
Bird::Bird(const Bird& copy) :Animal(copy.GetSpecies())
{

}
Bird& Bird::operator = (Bird&& rhs) noexcept
{
	if (this != &rhs)
	{
		Animal::operator = (static_cast<Animal&&>(rhs));
	}
	return *this;
}
Bird::Bird(Bird&& copy) noexcept : Animal(copy.GetSpecies())
{

}
void Bird::WhatAmI()
{
	cout << "I am a bird" << endl;
}