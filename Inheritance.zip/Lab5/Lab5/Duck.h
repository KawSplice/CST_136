//Name: Luis Solis
//Programming Assignment: Inheritance
#ifndef _Duck_H
#define _Duck_H

#include "Bird.h"

class Duck : public Bird
{
public:
	Duck();
	Duck(string points);
	~Duck();
	Duck& operator = (const Duck& rhs);
	Duck(const Duck& copy);
	Duck& operator = (Duck&& rhs) noexcept;
	Duck(Duck&& copy) noexcept;
	void WhatAmI();
private:

};
#endif

