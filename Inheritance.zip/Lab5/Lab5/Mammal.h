//Name: Luis Solis
//Programming Assignment: Inheritance
#ifndef _MAMMAL_H
#define _MAMMAL_H

#include <string>
#include "Animal.h"

using std::string;

class Mammal : virtual public Animal
{
public:
	Mammal();
	Mammal(string species);
	virtual ~Mammal();
	Mammal& operator = (const Mammal& rhs);
	Mammal(const Mammal& other);
	Mammal& operator = (Mammal&& rhs) noexcept;
	Mammal(Mammal&& other) noexcept;
	virtual void WhatAmI();
	//const string GetSpecies() const;
private:

};
#endif
