//Name: Luis
//Programming Assignment: Lab1

//defines and includes used
#include <iostream>
#include "Deck.h"
#include <crtdbg.h>
#define _CRTDBG_MAP_ALLOC
//using std
using std::endl;
using std::cout;
//functions
void card_function1(const Card&);
void card_function2(Card&);
void card_function3(Card*); 
void card_function4(Card);
Card card_function5();
Deck deck_function2();
void deck_function1(Deck);
//main
int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	cout << "1." << endl;
	Card card1;
	Card card2(1, "Spades");
	cout << "2." << endl;
	Card* card3;
	cout << "3." << endl;
	Card card4[3]{};
	cout << "4." << endl;
	Card card5 = card1; 
	cout << "5." << endl;
	card3 = new Card;
	cout << "6." << endl;
	card_function1(card2);
	cout << "7." << endl;
	card_function2(card5);
	cout << "8." << endl;
	card_function3(card3);
	cout << "9." << endl;
	card_function4(card2);
	cout << "10." << endl;
	card_function3(card4);
	cout << "11." << endl;
	card_function5();
	cout << "12." << endl;
	Deck deck1;
	cout << "13." << endl;
	delete card3;
	card3 = nullptr;
	cout << "14." << endl;
	deck_function2();
	cout << "15." << endl;
	deck_function1(deck1);
	cout << "end of main" << endl;
	return 0;
}
void card_function1(const Card&)
{

}
void card_function2(Card&)
{

}
void card_function3(Card*)
{

}
void card_function4(Card)
{

}
Card card_function5()
{
	Card local_card;
	return local_card;
}
void deck_function1(Deck)
{

}
Deck deck_function2()
{
	Deck value;
	return value;
}