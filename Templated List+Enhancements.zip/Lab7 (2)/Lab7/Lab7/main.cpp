//Name: Luis Solis
//Programming Assignment: Templated List Enhancements
#define _CRTDBG_MAP_ALLOC
#include <iostream>
#include <crtdbg.h>
#include "LinkedList.h"
#include "Node.h"
#include "Iterator.h"
using std::endl;
using std::cout;

template<class t> int comparisonfunc(t& comp, t& comp2);
template<class t> void traversefunc(t& num);
template<class t, class u>
void traversfunc2(t& num, u& otherNum);
int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	LinkedList<int> alist;
	LinkedList<char> newlist;

	newlist.InsertFront(76);
	newlist.InsertBack(83);
	newlist.InsertAt(86, 1);
	newlist.Sort(comparisonfunc<char>);
	cout << "sorted *****" << endl;
	newlist.ForEach(traversefunc);
	cout << "^^^^^^^^^" << endl;
	char test2 = 70;
	newlist.ForEach(traversfunc2, test2);
	cout << "after reversed" << endl;
	newlist.Reverse();
	newlist.ForEach(traversefunc);
	cout << "^^^^^^^^^^^^^^^^" << endl;
	for (char value1 : newlist)
		cout << value1 << endl;
	cout << " " << endl;
	cout << "!@#$%^&*()" << endl;

	alist.InsertFront(2);
	alist.InsertBack(3);
	alist.InsertBack(6);
	alist.InsertAt(7, 2);
	alist.Sort(comparisonfunc<int>);
	cout << "sorted ****" << endl;
	alist.ForEach(traversefunc);
	cout << "*****************" << endl;
	int test = 7;
	alist.ForEach(traversfunc2,test);
	cout << "after Reverse " << endl;
	alist.Reverse();
	alist.ForEach(traversefunc);
	cout << "*****************" << endl;
	for (int value : alist)
		cout << value << " ";
	cout << " " << endl;
	cout << "*****************" << endl;
	try
	{
		cout << alist.Front() << endl;
		cout << alist.Back() << endl;
		cout << alist.RemoveFront() << endl;
		cout << alist.RemoveBack() << endl;
		cout << alist.RemoveBack() << endl;
		cout << alist.RemoveBack() << endl;

		cout << newlist.Front() << endl;
		cout << newlist.Back() << endl;
	}
	catch (exception name)
	{
		cout << name.what() << endl;
	}
	return 0;
}

template<class t> int comparisonfunc(t& comp, t& comp2)
{
	int returning = 1;
	if (comp == comp2)
	{
		returning = 0;
	}
	else if (comp < comp2)
	{
		returning = -1;
	}
	return returning;
}
template<class t> void traversefunc(t& num)
{
	cout << num << endl;
}
template<class t, class u>
void traversfunc2(t& num, u& otherNum)
{
	cout << num << ", " << otherNum << endl;
}