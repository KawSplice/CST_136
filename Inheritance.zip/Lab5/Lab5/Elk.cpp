//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>
#include "Elk.h"

using std::cout;
using std::endl;

Elk::Elk() : Mammal("Elk"), m_points(0),Animal("tiger")
{
	//cout << "Elk default ctor" << endl;
}

Elk::Elk(int points) : Mammal("Elk"), m_points(points),Animal("tiger")
{
	//cout << "Elk one arg ctor" << endl;
}

Elk::~Elk()
{
	//cout << "Elk dtor" << endl;
}

Elk& Elk::operator = (const Elk& rhs)
{
	//cout << "Elk copy =" << endl;
	if (this != &rhs)
	{
		Mammal::operator = (rhs);
		m_points = rhs.m_points;
	}
	return *this;
}

Elk::Elk(const Elk& other) : Mammal(other), m_points(other.m_points),Animal("tiger")
{
	//cout << "Elk copy ctor" << endl;
}

Elk& Elk::operator = (Elk&& rhs) noexcept
{
	//cout << "Elk move =" << endl;
	if (this != &rhs)
	{
		Mammal::operator = (static_cast<Elk&&>(rhs));
		m_points = rhs.m_points;
	}
	return *this;
}

Elk::Elk(Elk&& other) noexcept : Mammal(static_cast<Elk&&>(other)), m_points(other.m_points),Animal("tiger")
{
	cout << "Elk move ctor" << endl;
}

void Elk::WhatAmI()
{
	cout << "I am an elk" << endl;
}
