//Name: Luis Solis
//Programming Assignment: Lab4
//defines and includes used
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "String.h"
using std::cout;
using std::endl;
using std::out_of_range;
//default
String::String() : c_string()
{
	cout << "String default ctor" << endl;
}
//copy
String::String(const String& other) : c_string(nullptr)
{
	cout << "String copy ctor" << endl;
	if (other.c_string != nullptr)
	{
		c_string = new char[strlen(other.c_string) + 1];
		strcpy(c_string, other.c_string);
	}
}
//dtor
String :: ~String()
{
	cout << "String dtor " << endl;
	delete[] c_string;
	c_string = nullptr;

}
//copy assignment
String& String :: operator = (const String& other)
{
	cout << "String copy =" << endl;
	if (this != &other)
	{
		delete[] c_string;
		if (other.c_string != nullptr)
		{
			c_string = new char[strlen(other.c_string) + 1];
			strcpy(c_string, other.c_string);
		}
		else
		{
			c_string = nullptr;
		}
	}
	return *this;

}
//move ctor
String::String(String&& other) : c_string(other.c_string)
{
	cout << "String move ctor" << endl;
	other.c_string = nullptr;
}
//move assignement
String& String :: operator = (String&& other)
{
	cout << "String move =" << endl;
	if (this != &other)
	{
		delete[] c_string;
		c_string = other.c_string;
		other.c_string = nullptr;
	}
	return *this;
}
//1 arg
String::String(const char* cstring) : c_string(nullptr)
{
	cout << "String 1 arg ctor" << endl;
	if (cstring != nullptr)
	{
		c_string = new char[strlen(cstring) + 1];
		strcpy(c_string, cstring);
	}
}
//GetCstring
const char* String::GetCString() const
{
	cout << "getString function" << endl;
	return c_string;
}
//GetSize
int String ::GetSize() const
{
	cout << "GetSize function" << endl;
	int num = 0;
	if (c_string != nullptr)
	{
		num = strlen(c_string);
	}
	return num; 
}
// < 
bool String::operator<(const String& other) const
{
	cout << "Operator < " << endl;
	if (_stricmp(c_string, other.c_string) < 0)
	{
		cout << "left hand side is smaller" << endl;
		return true;
	}
	else
	{
		cout << "right hand side is bigger" << endl;
		return false;
	}
}
bool String::operator>(const String& other) const
{
	cout << "Operator > " << endl;
	if (_stricmp(c_string, other.c_string) > 0)
	{
		cout << "left hand side is bigger" << endl;
		return true;
	}
	else
	{
		cout << "right hand side is smaller" << endl;
		return false;
	}
}
bool String::operator<=(const String& other) const
{
	cout << "Operator <= " << endl;
	if (_stricmp(c_string, other.c_string) <= 0)
	{
		cout << "left hand side is smaller" << endl;
		return true;
	}
	else
	{
		cout << "right hand side is bigger" << endl;
		return false;
	}
}
bool String::operator>=(const String& other) const
{
	cout << "Operator >= " << endl;
	if (_stricmp(c_string, other.c_string) >= 0)
	{
		cout << "left hand side is bigger" << endl;
		return true;
	}
	else
	{
		cout << "right hand side is smaller" << endl;
		return false;
	}
}
bool String::operator==(const String& other) const
{
	cout << "Operator == " << endl;
	if (_stricmp(c_string, other.c_string) == 0)
	{
		cout << "both the same" << endl;
		return true;
	}
	else
	{
		cout << "not the same" << endl;
		return false;
	}
}
bool String::operator!=(const String& other) const
{
	cout << "Operator != " << endl;
	if (_stricmp(c_string, other.c_string) != 0)
	{
		cout << "not the same" << endl;
		return true;
	}
	else
	{
		cout << "are the same" << endl;
		return false;
	}
}
String String::operator+(const String& other) const
{
	cout << "Operator + " << endl;
	String temp;
	temp.c_string = new char[strlen(other.c_string) + strlen(c_string) + 1];

	strcpy(temp.c_string, c_string);
	strcat(temp.c_string, other.c_string);
	
	return temp;
}
String& String::operator+=(const String& other)
{
	cout << "Operator += " << endl;
	*this = *this + other;
	return *this;
}
char String::operator[](int num) const
{
	cout << "operator[] " << endl;
	int temp = strlen(c_string);
	if (num > temp || num < 0)
	{
		cout << "element that is out of bounds or too small" << endl;
		throw out_of_range("element that is out of bounds or too small");
	}
	else
	{
		return c_string[num];
	}
}
