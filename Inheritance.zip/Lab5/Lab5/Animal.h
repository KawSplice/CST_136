//Name: Luis Solis
//Programming Assignment: Inheritance
#ifndef _Animal_H
#define _Animal_H

#include <string.h>

using std::string;

class Animal
{
public:
	//Animal();
	Animal(string other);
	virtual ~Animal();
	Animal& operator = (const Animal& rhs);
	Animal& operator = (Animal&& rhs) noexcept;
	virtual void WhatAmI();
	const string GetSpecies() const;
private:
	string m_species;
};
#endif
