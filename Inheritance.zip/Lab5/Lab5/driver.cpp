//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>
#include "Mammal.h"
#include "Elk.h"
#include "Otter.h"
#include "Duck.h"
#include "Bird.h"
#include "Platypus.h"
using std::cout;
using std::endl;

int main()
{
	//question1 
	Mammal m;
	Elk cow;
	Elk bull(3);
	Otter river(false);
	//question2
	m.WhatAmI();
	cow.WhatAmI();
	river.WhatAmI();
	//question3
	m = bull;
	//question4
	m.WhatAmI();
	//question5
	Elk Eastern_Elk = bull;
	//question6
	Mammal Monotremata = bull;
	//question7 /question20 / question 22 / question 25
	Animal* Marsupialia[6];
	//Marsupialia[0] = new Animal;
	Marsupialia[0] = new Mammal;
	Marsupialia[1] = new Elk;
	Marsupialia[2] = new Otter;
	Marsupialia[3] = new Bird;
	Marsupialia[4] = new Duck;
	Marsupialia[5] = new Platypus;

	for (int i = 0; i < 6; i++)
	{
		Marsupialia[i]->WhatAmI();
	}
	//question8
	for (int i = 0; i < 6; i++)
	{
		delete Marsupialia[i];
		Marsupialia[i] = nullptr;
	}
	//question9
	cout << sizeof(Elk) << endl;
	//question10
	cout << sizeof(Mammal) << endl;
	//question16
	cout << sizeof(Animal) << endl;
	//question17
	cout << sizeof(Elk) << endl;
	//question18
	cout << sizeof(Mammal) << endl;





	return 0;
}