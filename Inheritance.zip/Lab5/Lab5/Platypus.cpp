//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>
#include "Platypus.h"

using std::cout;
using std::endl;

Platypus::Platypus() :Otter(true), Duck("Robin"), Animal("tiger")
{
	//cout << "Platypus 3 arg ctor" << endl;
}
Platypus::~Platypus()
{
	//cout << "Platypus de ctor" << endl;
}
Platypus& Platypus::operator = (const Platypus& rhs)
{
	//cout << "Platypus copy =" << endl;
	if (this != &rhs)
	{
		Otter::operator=(rhs);
	}
	return *this;
}
Platypus::Platypus(const Platypus& copy) : Otter(copy),Duck(copy), Animal("tiger")
{
	//cout << << endl;
}
Platypus& Platypus::operator = (Platypus&& rhs) noexcept
{
	if (this != &rhs)
	{
		Otter::operator = (static_cast<Otter&&>(rhs));
	}
	return *this;
}
Platypus::Platypus(Platypus&& copy) noexcept : Otter(std::move(copy)),Duck(std::move(copy)), Animal("tiger")
{

}
void Platypus::WhatAmI()
{
	cout << "I am a Platypus" << endl;
}