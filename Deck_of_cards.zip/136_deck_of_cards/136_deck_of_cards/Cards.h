//Name: Luis Solis  
//Programming Assignment:Deck of cards 
#pragma once
//defines and includes used
#include <string>
//using std
using std::string;

class Card {
private:
	int rank;                                    //Ace,2,3,4,5,6,7,8,9,10,jack,queen,king	
	string suit;								 //spades, hearts, clubs, diamonds
public:
	Card();									     //default
	Card(const Card& rank);			             //copy ctor
	~Card();                                     //dtor 
	Card& operator = (const Card& rhs);	         //copy assignment
	Card(Card&& rank);						     //move ctor
	Card & operator = (Card && rhs);             //move assignment ctor 
	Card(int rank, string suit);			     //2arg ctor
};