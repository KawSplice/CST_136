//Name: Luis Solis
//Programming Assignment: Inheritance
#include <iostream>
#include "Animal.h"

using std::cout;
using std::endl;

//Animal::Animal() : m_species("")
//{
//	//cout << "Animal default ctor" << endl;
//}

Animal::Animal(string species) : m_species(species)
{
	cout << "Animal one arg ctor" << endl;
}

Animal::~Animal()
{
	//cout << "Animal dtor" << endl;
}

Animal& Animal::operator = (const Animal& rhs)
{
	//cout << "Animal copy =" << endl;
	if (this != &rhs)
	{
		m_species = rhs.m_species;
	}
	return *this;
}

//Animal::Animal(const Animal& other) : m_species(other.m_species)
//{
//	//cout << "Animal copy ctor" << endl;
//}

Animal& Animal::operator = (Animal&& rhs) noexcept
{
	//cout << "Animal move =" << endl;
	if (this != &rhs)
	{
		m_species = static_cast<string&&> (rhs.m_species);
	}
	return *this;
}

//Animal::Animal(Animal&& other) noexcept : m_species(other.m_species)
//{
//	cout << "Animal move ctor" << endl;
//}

void Animal::WhatAmI()
{
	cout << "I am a Animal" << endl;
}

const string Animal::GetSpecies() const
{
	return m_species;
}