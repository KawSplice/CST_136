//Name: Luis Solis
//Programming Assignment: Inheritance
#ifndef _Platypus_H
#define _Platypus_H

#include "Otter.h"
#include "Duck.h"

class Platypus : public Otter,Duck
{
public:
	Platypus();
	//Platypus(int points);
	~Platypus();
	Platypus& operator = (const Platypus& rhs);
	Platypus(const Platypus& copy);
	Platypus& operator = (Platypus&& rhs) noexcept;
	Platypus(Platypus&& copy) noexcept;
	void WhatAmI();
private:

};
#endif
