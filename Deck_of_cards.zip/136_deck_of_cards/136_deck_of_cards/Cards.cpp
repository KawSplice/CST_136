//Name: Luis Solis  
//Programming Assignment:Deck of cards 
//defines and includes used
#include<iostream>
#include"Cards.h"
//using std
using std::cout;
using std::endl;

//default
Card::Card() : rank(1), suit("Spades")
{
	cout << "Card default ctor" << endl;
}
//copy
Card::Card(const Card& other) : rank(other.rank), suit(other.suit)
{
	cout << "Card copy ctor" << endl;
}
//dtor
Card::~Card()
{
	cout << "Card dtor" << endl;
}
//copy assignment
Card& Card :: operator = (const Card& rhs) //  rank(other.rank), suit(other.suit)
{
	cout << "Card copy =" << endl;
	if (this != &rhs)
	{
		rank = rhs.rank;
		suit = rhs.suit;
	}
	return *this;
	
}
//move ctor 
Card::Card(Card&& other) : rank(other.rank), suit(std::move(other.suit))
{
	cout << "Card move ctor" << endl;
	
}
//move
Card & Card :: operator = (Card && rhs)
{
	cout << "Card move =" << endl;
	if (this != &rhs)
	{
		rank = rhs.rank;
		suit = std::move(rhs.suit);
	}
	return *this;
}
//2 arg constructor
Card::Card(int rank, string suit) : rank(rank), suit(suit)
{
	cout << "Card 2 arg ctor" << endl;
}