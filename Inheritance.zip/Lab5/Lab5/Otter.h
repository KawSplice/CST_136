//Name: Luis Solis
//Programming Assignment: Inheritance
#ifndef _OTTER_H
#define _OTTER_H

#include "Mammal.h"

class Otter : public Mammal
{
public:
	Otter();
	Otter(bool other);
	~Otter();
	Otter& operator = (const Otter& rhs);
	Otter(const Otter& copy);
	Otter& operator = (Otter&& rhs) noexcept;
	Otter(Otter&& copy) noexcept;
	void WhatAmI();
private:
	bool m_sea;
};
#endif