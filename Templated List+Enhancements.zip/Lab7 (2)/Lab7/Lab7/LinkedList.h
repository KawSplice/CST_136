//Name: Luis Solis
//Programming Assignment: Templated List Enhancements
#pragma once
#include <iostream>
#include "Node.h"
#include "Iterator.h"
using std::cout;
using std::endl;
using std::exception;

template <class data>
class LinkedList
{
private:
	int count;
	Node <data>* head;
public:
	LinkedList();
	LinkedList(const LinkedList& other);
	~LinkedList();
	LinkedList(LinkedList&& other);
	LinkedList& operator = (const LinkedList& other);
	LinkedList& operator = (LinkedList&& other);
	void Sort(int(*comparisonfunc)(data& arg1, data& arg2));
	void ForEach(void(*traverseFunc)(const data&));			    
	template<class U>
	void ForEach(void(*traverseFunc2)(data& arg1, U& arg2), U& other); 
	void Reverse();
	void InsertFront(data other);
	void InsertBack(data other);
	void InsertAt(data other, int num);
	data RemoveFront();
	data RemoveBack();
	data Front();
	data Back();
	void Clear();
	Iterator<data> begin();
	Iterator<data> end();

};

template <class data>
LinkedList<data>::LinkedList() :head(nullptr), count(0)
{
	cout << "LinkedList Default Ctor" << endl;
}

template <class data>
LinkedList<data>::LinkedList(const LinkedList& other) : head(other.head), count(other.count)
{
	cout << "LinkedList Copy Ctor" << endl;
}

template <class data>
LinkedList<data>::~LinkedList()
{
	cout << "LinkedList Dtor" << endl;
	Clear();
}

template <class data>
LinkedList<data>::LinkedList(LinkedList&& other) : head(std::move(other.head)), count(std::move(other.count))
{
	cout << "LinkedList Move Ctor" << endl;
	other.head = nullptr;
}

template <class data>
LinkedList<data>& LinkedList<data>::operator=(const LinkedList& other)
{
	cout << "LinkedList Copy Assignment" << endl;
	if (this != &other)
	{
		head = new Node<data>;
		*head = *(other.head);
		count = new int;
		*count = *(other.count);
	}
	return *this;
}

template <class data>
LinkedList<data>& LinkedList<data>::operator=(LinkedList&& other)
{
	cout << "LinkedList Move Assignment" << endl;
	if (this != &other)
	{
		head = std::move(other.head);
		count = std::move(other.count);
		other.head = nullptr;
	}
	return *this;
}

template <class data>
void LinkedList<data>::Sort(int(*comparisonfunc)(data& arg1, data& arg2))
{
	Node<data>* trail = head;  // p1 
	bool swp = false;

	while (swp == false)
	{
		swp = true;
		trail = head;
		while (trail->nextPointer->nextPointer!= nullptr)
		{

			Node<data>* travel = trail->nextPointer;  //p2
			Node<data>* hike = travel->nextPointer;   //p3

			if (head == trail)
			{
				if (comparisonfunc(trail->nodeData, travel->nodeData) > 0)
				{
					head = travel;
					trail->nextPointer = hike;
					travel->nextPointer = trail;

					trail = head;
					travel = head->nextPointer;
					hike = travel->nextPointer;
					swp = false;
				}
				if (comparisonfunc(travel->nodeData, hike->nodeData) > 0)
				{

					if (hike->nextPointer == nullptr)
					{

						trail->nextPointer = hike;
						travel->nextPointer = nullptr;
						hike->nextPointer = travel;

						trail = trail->nextPointer;
						swp = false;

					}
					else
					{
						trail->nextPointer = hike;
						travel->nextPointer = hike->nextPointer;
						hike->nextPointer = travel;

						trail = trail->nextPointer;
						swp = false;
					}


				}
				else
					trail = trail->nextPointer;

			}

			else if (comparisonfunc(travel->nodeData, hike->nodeData) > 0)
			{

				if (hike->nextPointer == nullptr)
				{

					trail->nextPointer = hike;
					travel->nextPointer = nullptr;
					hike->nextPointer = travel;

					trail = trail->nextPointer;
					swp = false;

				}
				else
				{
					trail->nextPointer = hike;
					travel->nextPointer = hike->nextPointer;
					hike->nextPointer = travel;

					trail = trail->nextPointer;
					swp = false;
				}

			}
			else
				trail = trail->nextPointer;

		}
	}


}

template <class data>
void LinkedList<data>::ForEach(void(*traverseFunc)(const data&))
{
	cout << "First ForEach Function " << endl;
	if (count != 0)
	{
		Node<data>* travel = head;
		while (travel->nextPointer != nullptr)
		{
			traverseFunc(travel->nodeData);
			travel = travel->nextPointer;
		}
		traverseFunc(travel->nodeData);
	}

}

template<class data>
template<class U>
void LinkedList<data>::ForEach(void(*traverseFunc2)(data& arg1, U& arg2), U& other)
{
	if (count != 0)
	{
		Node<data>* travel = head;
		while (travel->nextPointer != nullptr)
		{
			traverseFunc2(travel->nodeData, other);
			travel = travel->nextPointer;
		}
		traverseFunc2(travel->nodeData, other);
	}
}

template<class data>
void LinkedList<data>::Reverse()
{
	if (count != 0)
	{
		Node <data>* travel = head;
		Node <data>* prev = NULL;
		Node <data>* next = NULL;
		while (travel != nullptr)
		{
			next = travel->nextPointer;
			travel->nextPointer = prev;
			prev = travel;
			travel = next;
		}
		head = prev;
	}
}

template <class data>
void LinkedList<data>::InsertFront(data other)
{
	cout << "LinkedList InsertFront Function" << endl;
	head = new Node<data>(other, head);
	count++;
}
template <class data>
void LinkedList<data>::InsertBack(data other)
{
	cout << "LinkedList InsertBack Function" << endl;
	if (count == 0)
	{
		head = new Node<data>(other, head);
	}
	else
	{
		Node<data>* travel = head;
		while (travel->nextPointer != nullptr)
		{
			travel = travel->nextPointer;
		}
		Node<data>* newNode = new Node<data>(other, nullptr);
		travel->nextPointer = newNode;
	}
	count++;

}
template <class data>
void LinkedList<data>::InsertAt(data other, int num)
{
	cout << "LinkedList InsertAt Function" << endl;
	if (num < 0)
	{
		throw exception("the offset is invaild");
	}
	else if (num > count)
	{
		throw exception("the offset is invaild");
	}
	else if (count == 0 || num == 0)
	{
		InsertFront(other);
	}
	else if (count == num)
	{
		InsertBack(other);
	}
	else
	{
		Node<data>* temp = head;
		for (int i = 0; i != num - 1; i++)
		{
			temp = temp->nextPointer;
		}
		Node<data>* newNode = new Node<data>(other, temp->nextPointer);
		temp->nextPointer = newNode;

		count++;
	}
}

template <class data>
data LinkedList<data>::RemoveFront()
{
	cout << "LinkedList RemoveFront Function" << endl;
	if (count == 0)
	{
		throw exception("there isn't anything in the list");
	}
	Node<data>* temp = head;
	data headValue = temp->nodeData;
	head = head->nextPointer;
	delete temp;
	count--;
	return headValue;
}

template <class data>
data LinkedList<data>::RemoveBack()
{
	cout << "LinkedList RemoveBack Function" << endl;
	data headValue;
	if (count == 0)
	{
		throw exception("there isn't anything in the list");
	}
	else if (count == 1)
	{
		Node<data>* temp = head;
		headValue = temp->nodeData;
		head = head->nextPointer;
		delete temp;
		count--;
		return headValue;
	}
	else
	{
		Node<data>* travel = head;
		Node<data>* traveler = head->nextPointer;
		while (traveler->nextPointer != nullptr)
		{
			travel = traveler;
			traveler = traveler->nextPointer;
		}
		headValue = traveler->nodeData;
		delete traveler;
		travel->nextPointer = nullptr;
		count--;
		return headValue;
	}
}

template <class data>
data LinkedList<data>::Front()
{
	cout << "LinkedList Front Function" << endl;
	if (count == 0)
	{
		throw exception("there isn't anything in the list");
	}
	return head->nodeData;
}

template <class data>
data LinkedList<data>::Back()
{
	cout << "LinkedList Back Function" << endl;
	if (count == 0)
	{
		throw exception("there isn't anything in the list");
	}
	else
	{
		Node<data>* temp = head;
		while (temp->nextPointer != nullptr)
		{
			temp = temp->nextPointer;
		}
		return temp->nodeData;
	}
}

template <class data>
void LinkedList<data>::Clear()
{
	cout << "Clear is being used" << endl;
	while (head != nullptr)
	{
		Node<data>* temp = head;
		head = head->nextPointer;
		delete temp;
	}
	count = 0;

}

template<class data>
Iterator<data> LinkedList<data>::begin() 
{

	return Iterator<data>(head);
}

template<class data>
Iterator<data> LinkedList<data>::end()
{
	return Iterator<data>(nullptr);
}
