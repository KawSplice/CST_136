//Name: Luis Solis
//Programming Assignment: Templated List Enhancements
#pragma once
#include <iostream>
#include "LinkedList.h"
#include "Node.h"

class info;
template <class t>
class Iterator
{
	Node<t>* foo;
public:
	Iterator(Node<t>* other);
	bool operator != (const Iterator& other);
	Iterator& operator++();
	Iterator& operator++(int);
	t operator * ();

	Iterator();
	Iterator(const Iterator<t>& other);
	~Iterator();
	Iterator(Iterator<t>&& other);
	Iterator& operator = (const Iterator<t>& other);
	Iterator& operator = (Iterator<t>&& other);
};
template<class t>
Iterator<t>::Iterator(Node<t> * other) : foo(other)
{
}

template<class t>
bool Iterator<t>::operator!=(const Iterator& other)
{
	return foo != other.foo;
}

template<class t>
Iterator<t>& Iterator<t>::operator++()
{
	foo = foo->nextPointer;
	return *this;
}

template<class t>
Iterator<t>& Iterator<t>::operator++(int)
{
	
}

template<class t>
t Iterator<t>::operator*()
{
	return foo->nodeData;
}

template<class t>
Iterator<t>::Iterator() : foo(nullptr)  // default 
{
}

template<class t>
Iterator<t>::Iterator(const Iterator<t>& other) : foo(other.foo) // copy 
{
}

template<class t>
Iterator<t>::~Iterator() 
{
}

template<class t>
Iterator<t>::Iterator(Iterator<t>&& other): foo(std::move(other.foo))
{
}

template<class t>
Iterator<t>& Iterator<t>::operator=(const Iterator<t>& other)
{
	if (this != &other)
	{
		foo = other.foo;
	}
	return *this;
}

template<class t>
Iterator<t>& Iterator<t>::operator=(Iterator<t>&& other)
{
	if (this != &other)
	{
		foo = std::move(other.foo);
	}
	return *this;
}
